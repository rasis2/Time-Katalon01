<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Sign in_XAUpld</name>
   <tag></tag>
   <elementGuidId>7e904ca4-c505-4757-a72d-847ee094adfb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.U26fgb.mUbCce.fKz7Od.Wtw8H.kHssdc.pPQgvf.M9Bg4d.qs41qe > span.xjKiLb > span.Ce1Y1c > svg.XAUpld</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/following::*[name()='svg'][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>eb70c2f4-69fe-41e1-bf56-d8e1c9a310ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>width</name>
      <type>Main</type>
      <value>24</value>
      <webElementGuid>4d1344ee-a6fa-48b9-b7ff-33eb5453d923</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>height</name>
      <type>Main</type>
      <value>24</value>
      <webElementGuid>5785d222-dc2d-4dc8-a482-a422359f5a8a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>39f3776c-7e88-4771-9c31-9f383b59c134</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>focusable</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>661f9016-d199-4aa0-bb93-14b96b652e30</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>XAUpld</value>
      <webElementGuid>fb924574-8622-4a1a-b6d2-6f88de84071c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;yDmH0d&quot;)/div[@class=&quot;llhEMd bYEzqc iWO5td&quot;]/div[@class=&quot;mjANdc eEPege&quot;]/div[@class=&quot;g3VIld LhXUod Up8vH J9Nfi iWO5td&quot;]/div[@class=&quot;R6Lfte tOrNgd qRUolc Q2n72b&quot;]/div[@class=&quot;VY7JQd&quot;]/div[@class=&quot;U26fgb mUbCce fKz7Od Wtw8H kHssdc pPQgvf M9Bg4d qs41qe&quot;]/span[@class=&quot;xjKiLb&quot;]/span[@class=&quot;Ce1Y1c&quot;]/svg[@class=&quot;XAUpld&quot;]</value>
      <webElementGuid>f9ab347c-6a0e-4777-8ebb-148aa333c45c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>feb160bb-e2db-4857-b06c-41a1469b0a12</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>2186c431-f952-42c6-8776-c7c93c6cae9f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='In order to continue, you must sign in.'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>d2952e9e-36ce-46c4-9088-4c9ceef8190f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[2]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>ba9ac661-344b-46fd-ba90-64b233d5fb2d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
